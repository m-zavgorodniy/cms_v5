<?
	require $_SERVER['DOCUMENT_ROOT'].'/lib/templates/mailing/common.php';
?>