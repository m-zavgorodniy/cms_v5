<?
class CustomView extends View {

	function make_main_toolbar(&$toolbar) {

//		do nothing, disabled

	}

}
?>