<?
class CustomDeletePreview extends DeletePreview {

	function check_constraints() {

		return true;
	}
}

?>