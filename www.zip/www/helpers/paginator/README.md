paginator3000
=============

Official repository of  pagination script Paginator3000 - http://karaboz.ru/2007/11/19/paginator-3000-postranichnaya-navigaciya-budushhego/
